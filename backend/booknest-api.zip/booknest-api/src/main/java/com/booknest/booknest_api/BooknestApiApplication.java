package com.booknest.booknest_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BooknestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooknestApiApplication.class, args);
	}

}
